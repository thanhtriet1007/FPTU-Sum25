/*Q6: USING TEMPLATE
Calculate sum of digits of integer N input by keyboard

n=0 -> 0
n=8 -> 8
n=15 -> 6
n=245 -> 11
n=1000 -> 1

*/


#include <stdio.h>
#include <stdlib.h>
int main()
{
	//====DO NOT ADD NEW OR CHANGE STATEMENTS FROM LINE====
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int n,s;
	printf("Enter n = "); scanf("%d",&n);  
	//====DO NOT ADD NEW OR CHANGE STATEMENTS TO LINE====
	
	//Write your statements here
   
    
	//End your statements 
	
	//====DO NOT ADD NEW OR CHANGE STATEMENTS AFTER THIS LINE====
	//==THE OUTPUT AFTER THIS LINE WILL BE USED TO MARK YOUR PROGRAM==
	printf("\nOUTPUT:\n");
	printf("%d",s); 
	printf("\n");
	system ("pause");
	return(0);
}
