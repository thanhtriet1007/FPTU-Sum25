/*Q7: Using template

Hay tinh tong nghich dao cac chu so le cua so nguyen N

n=0 -> 0.00
n=7 -> 0.14
n=4 -> 0.00
n=24 -> 0.00
n=25 -> 0.20
n=15 -> 1.20
n=957 -> 0.45
n=2468 -> 0.0
n=25014 -> 1.20
n=8956572 -> 0.65
*/


#include <stdio.h>
#include <stdlib.h>
int main()
{
	//====DO NOT ADD NEW OR CHANGE STATEMENTS FROM LINE====
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int n;
	double s;
	printf("Enter n = "); scanf("%d",&n);  
	//====DO NOT ADD NEW OR CHANGE STATEMENTS TO LINE====
	
	//Write your statements here
   
    
	//End your statements 
	
	//====DO NOT ADD NEW OR CHANGE STATEMENTS AFTER THIS LINE====
	//==THE OUTPUT AFTER THIS LINE WILL BE USED TO MARK YOUR PROGRAM==
	printf("\nOUTPUT:\n");
	printf("%.2lf",s); 
	printf("\n");
	system ("pause");
	return(0);
}
