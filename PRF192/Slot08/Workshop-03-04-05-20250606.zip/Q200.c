/*
Hay nhap so nguyen n tu ban phim. 
Hay xuat ra man hinh cac gia tri ma n chia het , nhung nhỏ hon n

TEST CASE
INPUT
12
OUTPUT
1
2
3
4
6
*/


