// Q10: USING TEMPLATE
//Kiem tra mot so nguyen N co la so ma khi viet xuoi hay nguoc deu la chinh no
/*
N=6 -> 1
N=121 -> 1
N=8 -> 1
N=1 -> 1
N=17 -> 0
N=1111 -> 1
N=2442 -> 1
N=1235 -> 0
N=1222221 -> 1

*/



#include <stdio.h>
#include <stdlib.h>
int main()
{
	//====DO NOT ADD NEW OR CHANGE STATEMENTS FROM LINE====
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int n,s;
	printf("Enter n = "); scanf("%d",&n);  
	//====DO NOT ADD NEW OR CHANGE STATEMENTS TO LINE====
	
	//Write your statements here
   
    
	//End your statements 
	
	//====DO NOT ADD NEW OR CHANGE STATEMENTS AFTER THIS LINE====
	//==THE OUTPUT AFTER THIS LINE WILL BE USED TO MARK YOUR PROGRAM==
	printf("\nOUTPUT:\n");
	printf("%d",s); 
	printf("\n");
	system ("pause");
	return(0);
}
