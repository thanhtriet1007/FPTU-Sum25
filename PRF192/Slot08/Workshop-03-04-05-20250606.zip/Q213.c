// Q8: USING TEMPLATE
// Tinh tong cac uoc so nho hon N cua mot so nguyen duong N
/*
N=-5 -> 0
N=0 -> 0
N=1 -> 1
N=8 -> 1+2+4 = 7
N=7 -> 1
N=24 -> 1+2+3+4+6+8+12 = 36
*/

#include <stdio.h>
#include <stdlib.h>
int main()
{
	//====DO NOT ADD NEW OR CHANGE STATEMENTS FROM LINE====
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int n,s;
	printf("Enter n = "); scanf("%d",&n);  
	//====DO NOT ADD NEW OR CHANGE STATEMENTS TO LINE====
	
	//Write your statements here
   
    
	//End your statements 
	
	//====DO NOT ADD NEW OR CHANGE STATEMENTS AFTER THIS LINE====
	//==THE OUTPUT AFTER THIS LINE WILL BE USED TO MARK YOUR PROGRAM==
	printf("\nOUTPUT:\n");
	printf("%d",s); 
	printf("\n");
	system ("pause");
	return(0);
}
