/*Q13: Nhap 2 so nguyen n va m tu ban phim. Hay xuat ra cac so chia het
cho n nhung nho hon m
TESTCASE 1
INPUT
n=10
m=5
OUTPUT
end

TESTCASE 2
INPUT
n=4
m=19
OUTPUT
4
8
12
16
end
*/

