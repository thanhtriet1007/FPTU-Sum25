/*Q5: Hay nhap so nguyen n tu ban phim. Hay xuat ra man hinh
0 neu n khong la so chính phương
1 neu n la so chính phương
Biet rang so chính phương la số có giá trị bằng bình phương hai số nguyên

TEST CASE 1
INPUT
17
OUTPUT
1

TEST CASE 2
INPUT
4
OUTPUT
0

TEST CASE 3
INPUT
0
OUTPUT
0

TEST CASE 4
INPUT
1
OUTPUT
0

TEST CASE 5
INPUT
2
OUTPUT
1

TEST CASE 6
INPUT
0
OUTPUT
0

TEST CASE 7
INPUT
1
OUTPUT
0
*/

#include <stdio.h>
#include <stdlib.h>
int main()
{
	//====DO NOT ADD NEW OR CHANGE STATEMENTS FROM LINE====
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int n,s;
	printf("Enter n = "); scanf("%d",&n);  
	//====DO NOT ADD NEW OR CHANGE STATEMENTS TO LINE====
	
	//Write your statements here
   
    
	//End your statements 
	
	//====DO NOT ADD NEW OR CHANGE STATEMENTS AFTER THIS LINE====
	//==THE OUTPUT AFTER THIS LINE WILL BE USED TO MARK YOUR PROGRAM==
	printf("\nOUTPUT:\n");
	printf("%d",s); 
	printf("\n");
	system ("pause");
	return(0);
}