// Q9: USING TEMPLATE
// Kiem tra mot so nguyen N co la so hoan hao
// So hoan hao la so bang tong cac uoc so
/*
N=6 -> 1
N=28 -> 1
N=8 -> 0
N=20 -> 0
*/

#include <stdio.h>
#include <stdlib.h>
int main()
{
	//====DO NOT ADD NEW OR CHANGE STATEMENTS FROM LINE====
	system("cls");
	printf("\nTEST Q1 (2 marks):\n");
	int n,s;
	printf("Enter n = "); scanf("%d",&n);  
	//====DO NOT ADD NEW OR CHANGE STATEMENTS TO LINE====
	
	//Write your statements here
   
    
	//End your statements 
	
	//====DO NOT ADD NEW OR CHANGE STATEMENTS AFTER THIS LINE====
	//==THE OUTPUT AFTER THIS LINE WILL BE USED TO MARK YOUR PROGRAM==
	printf("\nOUTPUT:\n");
	printf("%d",s); 
	printf("\n");
	system ("pause");
	return(0);
}
